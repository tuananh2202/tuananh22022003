<!DOCTYPE html>
<HTML >
	<head>
		<title> chúc mừng sinh nhật</title>
		<meta charset="UFT-8">

	</head>

	<body background="./img/21.jpg" >
			<audio autoplay="autopaly">
				<source src="./img/HappyBirthday-VA_9ey.mp3" type="audio/mp3" />
			</audio>
		<h1 style="text-align: center;"><font color="#FF0000"><u><strong> HAPPY BIRTHDAY </strong></u></font></font></h1>
		<div style="color:#00FF00;font-size:20px;text-align: right;">
		<span class="say">nhân nhịp sinh nhật lần thứ 15 của m</span> <br>
		<span class="say"> m thì ko có ở đây :v </span><br>
		<span class="say"> à mà thổi nến đi đã :D </span></br></font>
		<a href="./2.php">nhấp đây để thổi nến</a></p></div>
		<img src="./img/nen-chay.gif" width="700px" height="600px">


	</body>
</HTML>
