<!DOCTYPE html>
<HTML >
	<head>
		<title> chúc mừng sinh nhật</title>
		<meta charset="UFT-8">

	</head>

	<body background="./img/21.jpg" width="1000px" height="900px">
		<h1 style="text-align: center;"><font color="#FF0000"><u><strong> HAPPY BIRTHDAY </strong></u></font></font></h1>
		<div style="color:#00FF00;font-size:20px;text-align: right;">
		<span class="say">t tặng quà rr đó nha >< </span> <br>
		<span class="say"> mốt đi học ko đc đòi nữa đâu đó</span><br>
		<span class="say"> khui ra coi đi >< </span></br></font>
		<a href="./4.php">nhấn đây để mở nè </a></p></div>

		<img src="./img/qua.jfif" width="700px" height="600px">
		

	</body>
</HTML>