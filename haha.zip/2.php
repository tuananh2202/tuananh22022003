<!DOCTYPE html>
<HTML >
	<head>
		<title> chúc mừng sinh nhật</title>
		<meta charset="UFT-8">

	</head>

	<body background="./img/21.jpg" width="1000px" height="900px">
		<h1 style="text-align: center;"><font color="#FF0000"><u><strong> HAPPY BIRTHDAY </strong></u></font></font></h1>
		
		<div style="color:#00FF00;font-size:20px;text-align: right;">
		<span class="say">năm nay m ko có ở đây</span> <br>
		<span class="say"> tụi t cũng chả có j cho m :v</span><br>
		<span class="say"> à mà cầu nguyện chưa.thổi nến phải cầu nguyện chứ :D </span></br></font>
		<a href="./3.php ?>">cầu nguyện xong nhấp đây nha >< </a></p></div>
		<img src="./img/nen-tat.gif" width="700px" height="600px">
		


	</body>
</HTML>